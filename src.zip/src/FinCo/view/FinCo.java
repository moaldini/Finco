package FinCo.view;

import FinCo.controller.AppMain;
import FinCo.model.ICommandManager;

public class FinCo {
	private AppMain appMain;
	private ICommandManager commandManager;
}
