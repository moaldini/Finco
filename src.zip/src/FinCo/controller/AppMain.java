package FinCo.controller;

import java.util.List;

import FinCo.model.AbstractAccountDB;
import FinCo.model.CustomerDB;

public class AppMain {
	private List<AbstractAccountDB> accountDb;
	private List<CustomerDB> customerDB;
}
