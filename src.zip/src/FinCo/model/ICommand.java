package FinCo.model;

public interface ICommand {
	public void execute();
}
