package FinCo.model;

public class Withdraw extends EntryType {

}
