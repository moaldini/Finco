package FinCo.model;

public interface IAccount {
	public void deposit(Double amount);
	public void withdraw(Double amount);
}
