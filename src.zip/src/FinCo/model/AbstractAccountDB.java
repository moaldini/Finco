package FinCo.model;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractAccountDB{
	
	//public abstract AbstractAccount findAccountByNumber(Long accNum);

}
