package FinCo.model;

public interface ICustomer {
	public void sendEmail(String email);
	public void addAccount(AbstractAccount account );
}
