package FinCo.model;

public class CustomerDB implements ICustomerDB {

	@Override
	public AbCustomer findPersonByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
