package FinCo.model;

public class Deposit extends EntryType {

}
