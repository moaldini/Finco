package FinCo.model;

public interface ICustomerDB {
	public AbCustomer findPersonByName(String name);
}
