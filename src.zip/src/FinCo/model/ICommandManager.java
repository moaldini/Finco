package FinCo.model;

public interface ICommandManager {
	public void submit(ICommand command);
}
