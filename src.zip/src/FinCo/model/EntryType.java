package FinCo.model;

public abstract class EntryType {

}
