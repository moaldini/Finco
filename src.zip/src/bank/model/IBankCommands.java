package bank.model;

import FinCo.model.ICommand;

public interface IBankCommands extends ICommand {
	public void execute();
}
