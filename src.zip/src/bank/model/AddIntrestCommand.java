package bank.model;

public class AddIntrestCommand implements IBankCommands  {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}