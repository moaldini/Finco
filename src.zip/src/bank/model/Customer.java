package bank.model;

import FinCo.model.AbCustomer;

public abstract class Customer extends AbCustomer {
	public Customer(String name, String emailAdress) {
		super(name, emailAdress);
		// TODO Auto-generated constructor stub
	}

}
