package bank.view;

import FinCo.view.FinCo;

public class Bank extends FinCo {
	public void refreshDisplay() {
		
	}
}
