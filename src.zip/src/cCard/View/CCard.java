package cCard.View;

public class CCard {

	public void refreshDisplay() {
		
	}
}
