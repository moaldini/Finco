package cCard.Model;

public interface ICreditCardObserver {
	public void update();
}
