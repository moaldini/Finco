package cCard.Model;

import FinCo.model.ICommand;

public interface CCardCommands extends ICommand   {
	public void execute();
}
