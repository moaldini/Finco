package cCard.Model;

public class AddIntrestCommand implements CCardCommands  {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}